import React, {useEffect, useState} from 'react'

const SkeletonLoader = () => {
   


  return (
    <div>SkeletonLoader</div>
  )
}

export default SkeletonLoader