const Donate_Btn = () => {
    return (
        <button className="bg-gradient-to-r from-blue-200 to-teal-200 p-3 rounded-xl shadow-lg shadow-white-500/50"> Donate Now </button>
    )
}

export default Donate_Btn;

