import React, {useEffect, useState} from 'react'
import AdminTemplate from "./AdminTemplate";

const AddSermons = () => {
  return (
    <div>AddSermons</div>
  )
}

export default AddSermons;