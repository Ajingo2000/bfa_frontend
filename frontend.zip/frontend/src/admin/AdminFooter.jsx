import React from 'react'

const AdminFooter = () => {
  return (
    <div>AdminFooter</div>
  )
}

export default AdminFooter