import React, {useEffect, useState} from 'react'
import AdminTemplate from "./AdminTemplate";

const BelieversDocsDashboard = () => {
  return (
    <div></div>
  )
}

export default BelieversDocsDashboard