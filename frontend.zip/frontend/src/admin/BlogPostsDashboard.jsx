import React from 'react'

const BlogPostsDashboard = () => {
  return (
    <div>BlogPostsDashboard</div>
  )
}

export default BlogPostsDashboard