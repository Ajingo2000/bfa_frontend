import React from 'react'

const SermonsDashboard = () => {
  return (
    <div>SermonsDashboard</div>
  )
}

export default SermonsDashboard